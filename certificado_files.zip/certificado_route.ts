import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '../../../../lib/auth'
import { connectDB } from '../../../../lib/db'
import Certificate from '../../../../models/Certificate'
import { gerarHTMLCertificado } from '../../../../lib/certificado-template'
import { mkdir, writeFile } from 'fs/promises'
import path from 'path'

export async function GET(
  req: NextRequest,
  { params }: { params: { codigo: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

    await connectDB()

    const cert = await Certificate.findOne({ codigo: params.codigo })
      .populate('usuario_id', 'nome cpf email')
      .populate('curso_id', 'titulo nr carga_horaria validade_anos conteudo_programatico')
      .lean() as any

    if (!cert) return NextResponse.json({ error: 'Certificado não encontrado' }, { status: 404 })

    // Verifica se o certificado pertence ao usuário (ou é admin)
    if (
      cert.usuario_id._id.toString() !== session.user.id &&
      session.user.papel !== 'admin'
    ) {
      return NextResponse.json({ error: 'Acesso negado' }, { status: 403 })
    }

    // Se já tem PDF gerado, redireciona
    if (cert.url_pdf && cert.url_pdf !== '') {
      return NextResponse.redirect(new URL(cert.url_pdf, req.url))
    }

    // Gera o PDF com Puppeteer
    const puppeteer = (await import('puppeteer')).default

    const browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
    })

    const page = await browser.newPage()
    const html = gerarHTMLCertificado(cert)
    await page.setContent(html, { waitUntil: 'networkidle0' })

    const pdfBuffer = await page.pdf({
      format: 'A4',
      landscape: true,
      printBackground: true,
      margin: { top: '0', bottom: '0', left: '0', right: '0' },
    })

    await browser.close()

    // Salva o PDF em disco
    const dirPath = path.join(process.cwd(), 'public', 'certificados')
    await mkdir(dirPath, { recursive: true })
    const fileName = `${cert.codigo}.pdf`
    const filePath = path.join(dirPath, fileName)
    await writeFile(filePath, pdfBuffer)

    // Atualiza a URL no banco
    const urlPdf = `/certificados/${fileName}`
    await Certificate.findByIdAndUpdate(cert._id, { url_pdf: urlPdf })

    // Retorna o PDF
    return new NextResponse(pdfBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="certificado-${cert.codigo}.pdf"`,
      },
    })
  } catch (error) {
    console.error('[CERTIFICADO PDF]', error)
    return NextResponse.json({ error: 'Erro ao gerar certificado' }, { status: 500 })
  }
}
