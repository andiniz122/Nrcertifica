import { ICertificate } from '../models/Certificate'

export function gerarHTMLCertificado(cert: any): string {
  const dados = cert.dados
  const cpfFormatado = dados.cpf?.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4')
  const dataInicio = new Date(dados.data_inicio).toLocaleDateString('pt-BR')
  const dataConclusao = new Date(dados.data_conclusao).toLocaleDateString('pt-BR')
  const dataValidade = new Date(dados.data_validade).toLocaleDateString('pt-BR')
  const nota = dados.nota_final
  const percentual = Math.round((nota / 10) * 100)

  const conteudoProgramatico = dados.conteudo_programatico || []

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Times New Roman', serif; background: white; }

  /* ── PÁGINA 1 — FRENTE ── */
  .pagina {
    width: 297mm;
    height: 210mm;
    position: relative;
    overflow: hidden;
    background: white;
    page-break-after: always;
  }

  /* Bordas decorativas */
  .borda-topo-esq {
    position: absolute; top: 0; left: 0;
    width: 0; height: 0;
    border-style: solid;
    border-width: 55mm 45mm 0 0;
    border-color: #1A1A2E transparent transparent transparent;
  }
  .borda-topo-dir {
    position: absolute; top: 0; right: 0;
    width: 0; height: 0;
    border-style: solid;
    border-width: 55mm 0 0 45mm;
    border-color: #1A1A2E transparent transparent transparent;
  }
  .wave-bottom {
    position: absolute; bottom: 0; left: 0; right: 0; height: 42mm;
    background: linear-gradient(135deg, #1A1A2E 0%, #2d2d50 40%, #C8102E 70%, #F5A623 100%);
    clip-path: ellipse(55% 100% at 50% 100%);
  }
  .wave-bottom-2 {
    position: absolute; bottom: 0; left: 0; right: 0; height: 35mm;
    background: rgba(255,255,255,0.08);
    clip-path: ellipse(45% 100% at 30% 100%);
  }

  /* Logo hexagonal */
  .logo-hex {
    position: absolute; top: 10mm; left: 12mm;
    width: 28mm; height: 28mm;
    background: #C8102E;
    clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);
    display: flex; align-items: center; justify-content: center;
  }
  .logo-inner {
    text-align: center; color: white;
  }
  .logo-inner .nr { font-size: 9pt; font-weight: 900; letter-spacing: 1px; line-height: 1; }
  .logo-inner .certifica { font-size: 6.5pt; font-weight: 700; letter-spacing: 0.5px; line-height: 1.1; }
  .logo-inner .subtag { font-size: 4pt; font-style: italic; line-height: 1.2; margin-top: 1mm; }

  /* Título CERTIFICADO */
  .titulo-cert {
    position: absolute; top: 12mm; left: 50mm; right: 12mm;
    font-family: Arial, sans-serif;
    font-size: 42pt; font-weight: 900;
    color: #1A1A2E; letter-spacing: 2px;
    text-align: right;
  }

  /* Corpo do certificado */
  .corpo {
    position: absolute; top: 52mm; left: 18mm; right: 18mm;
    text-align: center;
  }
  .corpo .certificamos {
    font-size: 11pt; color: #333; line-height: 1.6;
  }
  .corpo .nome-aluno {
    font-size: 13pt; font-weight: 700; color: #1A1A2E;
  }
  .corpo .cpf-info {
    font-size: 10.5pt; color: #333;
  }
  .corpo .frequencia {
    font-size: 11pt; color: #333;
  }
  .corpo .carga {
    font-size: 12pt; font-weight: 700; color: #1A1A2E;
  }
  .corpo .nome-curso {
    font-size: 14pt; font-weight: 900; color: #1A1A2E;
    margin: 4mm 0 3mm;
    border-top: 0.3mm solid #eee;
    border-bottom: 0.3mm solid #eee;
    padding: 2mm 0;
  }
  .corpo .base-legal {
    font-size: 8pt; color: #555; line-height: 1.5;
    margin-top: 2mm;
  }

  /* Assinaturas */
  .assinaturas {
    position: absolute; bottom: 46mm; left: 18mm; right: 18mm;
    display: flex; align-items: flex-end; justify-content: space-between;
  }
  .assin-aluno { text-align: center; flex: 0 0 50mm; }
  .assin-aluno .linha { border-top: 0.3mm solid #333; margin-bottom: 2mm; }
  .assin-aluno .label { font-size: 10pt; font-weight: 700; color: #1A1A2E; }

  .medalha { flex: 0 0 30mm; text-align: center; }
  .medalha svg { width: 22mm; height: 22mm; }

  .assin-resp { text-align: center; flex: 0 0 65mm; }
  .assin-resp .linha-assin { border-top: 0.3mm solid #333; margin-bottom: 1mm; }
  .assin-resp .nome-resp { font-size: 10.5pt; font-weight: 700; color: #1A1A2E; }
  .assin-resp .cargo { font-size: 7.5pt; color: #444; line-height: 1.4; }

  /* ── PÁGINA 2 — VERSO (Conteúdo Programático) ── */
  .pagina-verso {
    width: 297mm;
    height: 210mm;
    position: relative;
    overflow: hidden;
    background: white;
    padding: 10mm 14mm;
  }

  .verso-header {
    display: flex; align-items: center; gap: 5mm;
    border-bottom: 0.5mm solid #C8102E;
    padding-bottom: 3mm; margin-bottom: 4mm;
  }
  .verso-logo-mini {
    width: 14mm; height: 14mm;
    background: #C8102E;
    clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);
    display: flex; align-items: center; justify-content: center; flex-shrink: 0;
  }
  .verso-logo-mini span { color: white; font-size: 5pt; font-weight: 900; text-align: center; line-height: 1.1; }

  .verso-titulo h1 { font-size: 13pt; font-weight: 900; color: #1A1A2E; line-height: 1.2; }
  .verso-titulo h2 { font-size: 9pt; color: #C8102E; font-weight: 700; letter-spacing: 0.5px; }

  .conteudo-grid {
    display: grid; grid-template-columns: 1fr 1fr;
    gap: 2mm 6mm; margin-bottom: 3mm;
  }
  .item-conteudo {
    font-size: 7pt; color: #333; line-height: 1.4;
    padding-left: 3mm; border-left: 1.5px solid #C8102E;
  }

  .verso-footer {
    position: absolute; bottom: 6mm; left: 14mm; right: 14mm;
    display: flex; align-items: flex-end; justify-content: space-between;
    border-top: 0.3mm solid #eee; padding-top: 3mm;
  }
  .base-legal-verso { font-size: 6.5pt; color: #666; line-height: 1.5; flex: 1; }
  .assin-verso { text-align: right; flex: 0 0 55mm; }
  .assin-verso .linha-v { border-top: 0.3mm solid #333; margin-bottom: 1mm; }
  .assin-verso .nome-v { font-size: 8.5pt; font-weight: 700; color: #1A1A2E; }
  .assin-verso .cargo-v { font-size: 6.5pt; color: #444; line-height: 1.4; }
  .codigo-box {
    font-size: 6pt; color: #888;
    background: #f5f5f5; border-radius: 2mm;
    padding: 1mm 2mm; margin-top: 2mm;
  }

  @media print {
    .pagina, .pagina-verso { page-break-after: always; }
  }
</style>
</head>
<body>

<!-- ── PÁGINA 1: FRENTE ── -->
<div class="pagina">
  <div class="borda-topo-esq"></div>
  <div class="borda-topo-dir"></div>
  <div class="wave-bottom"></div>
  <div class="wave-bottom-2"></div>

  <!-- Logo -->
  <div class="logo-hex">
    <div class="logo-inner">
      <div class="nr">NR</div>
      <div class="certifica">CERTIFICA</div>
      <div class="subtag">"Capacitação que<br>protege vidas"</div>
    </div>
  </div>

  <!-- Título -->
  <div class="titulo-cert">CERTIFICADO</div>

  <!-- Corpo -->
  <div class="corpo">
    <p class="certificamos">
      Certificamos que <span class="nome-aluno">${dados.nome_aluno}</span>, CPF ${cpfFormatado},<br>
      concluiu com <strong>100% de frequência</strong> o curso com carga horária de <span class="carga">${dados.carga_horaria}:</span>
    </p>
    <div class="nome-curso">${dados.titulo_curso}</div>
    <p class="base-legal">
      O Curso foi realizado de ${dataInicio} à ${dataConclusao} com base legal na Constituição/88 Artigo 206° Inciso II e Artigo 209°,<br>
      Lei n° 9.394/96, Decreto n° 5.154/2004 e Norma CNE n° 04/99 - MEC (Ministério da Educação) Artigo 7°§ 3°.<br>
      O Aluno obteve aproveitamento de <strong>${percentual}%</strong> na avaliação de conhecimento aplicada no final do curso.
    </p>
  </div>

  <!-- Assinaturas -->
  <div class="assinaturas">
    <div class="assin-aluno">
      <div class="linha"></div>
      <div class="label">Aluno(a)</div>
    </div>

    <div class="medalha">
      <!-- Medalha SVG -->
      <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
        <circle cx="50" cy="42" r="30" fill="#F5A623" stroke="#e09015" stroke-width="2"/>
        <circle cx="50" cy="42" r="24" fill="#FFD700" stroke="#F5A623" stroke-width="1.5"/>
        <circle cx="50" cy="42" r="18" fill="#FFF0A0" stroke="#F5A623" stroke-width="1"/>
        <polygon points="50,25 54,37 67,37 57,45 61,57 50,49 39,57 43,45 33,37 46,37" fill="#F5A623" stroke="#e09015" stroke-width="0.5"/>
        <path d="M40,68 L35,85 L50,78 L65,85 L60,68" fill="#C8102E"/>
        <path d="M40,68 L35,85 L50,78" fill="#a00020"/>
        <path d="M40,68 L60,68 L50,58 Z" fill="#F5A623"/>
      </svg>
    </div>

    <div class="assin-resp">
      <div class="linha-assin"></div>
      <div class="nome-resp">${dados.instrutor || 'Anderson Bicalho Diniz'}</div>
      <div class="cargo">
        Instrutor e responsável Técnico<br>
        Engenheiro Eletricista<br>
        Engenheiro Segurança do Trabalho<br>
        Crea: ${dados.crea || '254516/MG'}
      </div>
    </div>
  </div>
</div>

<!-- ── PÁGINA 2: VERSO ── -->
<div class="pagina-verso">
  <div class="verso-header">
    <div class="verso-logo-mini"><span>NR<br>CERT</span></div>
    <div class="verso-titulo">
      <h1>${dados.titulo_curso}</h1>
      <h2>CONTEÚDO PROGRAMÁTICO — ${dados.carga_horaria?.toUpperCase()}</h2>
    </div>
  </div>

  <div class="conteudo-grid">
    ${conteudoProgramatico.map((item: string) => `
      <div class="item-conteudo">${item}</div>
    `).join('')}
  </div>

  <div class="verso-footer">
    <div class="base-legal-verso">
      Curso (modalidade EAD) com fundamento legal na Constituição Federal/88 Artigo 206o Inciso II e Artigo 209o,<br>
      Lei no 9.394/96, Decreto no 5.154/2004 e Norma CNE no 04/99 - MEC (Ministério da Educação) Artigo 7o § 3o.<br>
      Validade do treinamento: ${dados.data_validade ? `até ${dataValidade}` : `${2} anos`}.<br>
      <div class="codigo-box">Código de verificação: ${cert.codigo} · Verifique em: nrcertifica.com.br/validar/${cert.codigo}</div>
    </div>
    <div class="assin-verso">
      <div class="linha-v"></div>
      <div class="nome-v">${dados.instrutor || 'Anderson Bicalho Diniz'}</div>
      <div class="cargo-v">
        Engenheiro Eletricista<br>
        Engenheiro Segurança do trabalho<br>
        Eletricom Manutenção Especializada<br>
        CREA: ${dados.crea || '254516/MG'}<br>
        Registro Nacional: 1419524216
      </div>
    </div>
  </div>
</div>

</body>
</html>`
}
